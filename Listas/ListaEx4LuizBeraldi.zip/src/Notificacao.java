interface Notificacao {
    String formatarMensagem(String mensagem);
}