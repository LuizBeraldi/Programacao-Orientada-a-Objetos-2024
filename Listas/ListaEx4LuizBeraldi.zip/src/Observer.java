interface Observer {
    void atualizar(String message);
}