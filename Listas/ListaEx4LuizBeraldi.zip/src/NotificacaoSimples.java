class NotificacaoSimples implements Notificacao {
    @Override
    public String formatarMensagem(String mensagem) {
        return mensagem;
    }
}