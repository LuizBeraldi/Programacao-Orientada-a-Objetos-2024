interface Veiculo {
    void mover(double distancia);
    void abastecer(double quantidade);
    String getPlaca();
}