interface Manutencao {
    void realizarManutencao();
}